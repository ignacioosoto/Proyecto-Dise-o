from flask import Flask, jsonify, request, render_template
import json
import uuid

app = Flask(__name__)

def load_data():
    with open('data.json') as f:
        return json.load(f)

def save_data(data):
    with open('data.json', 'w') as f:
        json.dump(data, f, indent=4)

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/filter_results')
def filter_results():
    return render_template('filter_results.html')

@app.route('/api/data', methods=['GET'])
def get_data():
    data = load_data()
    return jsonify(data)

@app.route('/api/data', methods=['POST'])
def add_data():
    new_entry = request.json
    new_entry['id'] = str(uuid.uuid4())
    data = load_data()
    data.append(new_entry)
    save_data(data)
    return jsonify(new_entry), 201

@app.route('/api/data/filter', methods=['GET'])
def filter_data():
    data = load_data()
    age = request.args.get('age', type=int)
    sex = request.args.get('sex')
    region = request.args.get('region')
    country = request.args.get('country')
    
    if age is not None:
        data = [d for d in data if d['age'] >= age]
    if sex:
        data = [d for d in data if d['sex'] == sex]
    if region:
        data = [d for d in data if d['region'] == region]
    if country:
        data = [d for d in data if d['country'] == country]
    
    filtered_data = {
        'count': len(data),
        'data': data
    }
    
    # Save filtered data to a new file for display
    with open('filtered_data.json', 'w') as f:
        json.dump(filtered_data, f, indent=4)
    
    return jsonify(filtered_data)

if __name__ == '__main__':
    app.run(debug=True)
