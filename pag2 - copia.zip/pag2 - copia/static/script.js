document.addEventListener('DOMContentLoaded', () => {
    const dataDisplay = document.getElementById('data-display');
    const addDataForm = document.getElementById('add-data-form');
    const filterDataForm = document.getElementById('filter-data-form');

    function fetchData(url, callback) {
        fetch(url)
            .then(response => response.json())
            .then(data => callback(data))
            .catch(error => console.error('Error fetching data:', error));
    }

    function displayData(data, elementId) {
        const element = document.getElementById(elementId);
        if (element) {
            element.textContent = JSON.stringify(data, null, 2);
        }
    }

    addDataForm.addEventListener('submit', event => {
        event.preventDefault();
        const formData = new FormData(addDataForm);
        const jsonData = {
            name: formData.get('name'),
            age: parseInt(formData.get('age')),
            sex: formData.get('sex'),
            disability: formData.get('disability') === 'true',
            region: formData.get('region'),
            country: formData.get('country'),
            income: parseInt(formData.get('income'))
        };

        fetch('/api/data', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(jsonData)
        })
        .then(response => response.json())
        .then(data => {
            alert('Data added: ' + JSON.stringify(data));
            fetchData('/api/data', (data) => displayData(data, 'data-display')); // Refresh the data displayed
        })
        .catch(error => console.error('Error adding data:', error));
    });

    filterDataForm.addEventListener('submit', event => {
        event.preventDefault();
        const formData = new FormData(filterDataForm);
        const queryParams = new URLSearchParams();
        
        if (formData.get('filter-age')) {
            queryParams.append('age', formData.get('filter-age'));
        }
        if (formData.get('filter-sex')) {
            queryParams.append('sex', formData.get('filter-sex'));
        }
        if (formData.get('filter-region')) {
            queryParams.append('region', formData.get('filter-region'));
        }
        if (formData.get('filter-country')) {
            queryParams.append('country', formData.get('filter-country'));
        }

        const url = `/api/data/filter?${queryParams.toString()}`;
        
        fetch(url)
            .then(response => response.json())
            .then(data => {
                localStorage.setItem('filteredData', JSON.stringify(data.data));
                localStorage.setItem('filteredCount', data.count);
                window.location.href = '/filter_results';
            })
            .catch(error => console.error('Error filtering data:', error));
    });

    if (window.location.pathname === '/filter_results') {
        const filteredData = JSON.parse(localStorage.getItem('filteredData'));
        const filteredCount = localStorage.getItem('filteredCount');
        document.getElementById('result-count').textContent = `${filteredCount} results found.`;
        displayData(filteredData, 'filtered-data-display');
    }

    // Initial fetch to display all data
    if (dataDisplay) {
        fetchData('/api/data', (data) => displayData(data, 'data-display'));
    }
});
